
package dbview;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.*; 
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class External {
    public static String url = "jdbc:sqlite:C:/myDB/database.db";
    
    public static void copy(){
        
        new File("c:/myDB/").mkdir(); //creates the folder were the DB will be saved.
        
        File source = new File("src/dbview/database.db");
        File dest = new File("/myDB/database.db");
        try {
            Files.copy(source.toPath(), dest.toPath());
            JOptionPane.showMessageDialog(null,("Database & Table Created & Populated!"));
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null,("Folder & Database may already exist: "+ex.getMessage()));
        }
        
    }//end copy
    
    public static void viewpanel(){
        //jtable must be public static, viewtable is the jtable swing name
        //you must also edit the table contents-columns, usually they would mach what comes from the resultset
        //Since my jtable is not used to edit data, strings are fine
        DefaultTableModel tm = (DefaultTableModel) MainFrame.viewtable.getModel();
        try (Connection conn = DriverManager.getConnection(url)) {
            //Statement – Used to execute string-based SQL queries
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM AGENTS"); //get everything from table, result set
            tm.setRowCount(0);
            while(rs.next()){ //rs is result set, use while to iterate through it
                tm.addRow(new Object[]{rs.getString("AGENT_CODE"), rs.getString("AGENT_NAME"), rs.getString("WORKING_AREA"), rs.getFloat("COMMISSION"), rs.getString("PHONE_NO"), rs.getString("COUNTRY")});
            }//end while
            
            conn.close();
            stmt.close();
            rs.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,(e.getMessage())); //if there is an error a popup is issued
        }//end try catch
    }

    
}
